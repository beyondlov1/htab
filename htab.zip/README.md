# htab
a chrome extension, hide tabs when exceeding a certain number

### install
```
cd htab
zip -r htab.zip ./*
```
or
extension manager => load unpacked

